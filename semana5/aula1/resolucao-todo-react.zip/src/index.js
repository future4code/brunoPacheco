import React, { Component } from "react";
import { render } from "react-dom";
import styled from "styled-components";
import Task from "./Task";
import "./style.css";

const AllTasksWrapper = styled.div`
  display: grid;
`;

class App extends Component {
  constructor() {
    super();
    this.state = {
      allTasks: [],
      currentTask: ""
    };
  }

  componentDidMount(){
    const storedTasks = JSON.parse(window.localStorage.getItem("allTasks"));
    
    if(storedTasks !== null){
      this.setState({
        allTasks: storedTasks,
      })
    }
  };

  onChangeCurrentTask = (event) => {
    this.setState({ currentTask: event.target.value });
  };

  onClickCreateTask = () => {
    const newTask = {
      id: Date.now(),
      text: this.state.currentTask,
      isDone: false
    };

    const allNewTasks = [...this.state.allTasks, newTask];

    this.setState({
      allTasks: allNewTasks,
      currentTask: ""
    });
  };

  onUpdateTask = (event, task) => {
    debugger;
    const allNewTasks = [...this.state.allTasks];
    const newTaskText = event.target.value;

    const indexToBeEdited = allNewTasks.findIndex(newTask => {
      return newTask.id === task.id;
    });

    allNewTasks[indexToBeEdited] = {
      id: task.id,
      text: newTaskText,
      isDone: task.isDone
    };

    this.setState({
      allTasks: allNewTasks
    });
  };

  onCompleteTask = task => {
    const allNewTasks = [...this.state.allTasks];

    const indexToBeEdited = allNewTasks.findIndex(newTask => {
      return newTask.id === task.id;
    });

    allNewTasks[indexToBeEdited] = { text: task.text, isDone: true };

    this.setState({
      allTasks: allNewTasks
    });
  };

  onInCompleteTask = task => {
    const allNewTasks = [...this.state.allTasks];

    const indexToBeEdited = allNewTasks.findIndex(newTask => {
      return newTask.id === task.id;
    });

    allNewTasks[indexToBeEdited] = { text: task.text, isDone: false };

    this.setState({
      allTasks: allNewTasks
    });
  };

  onRemoveTask = task => {
    const allNewTasks = [...this.state.allTasks];
    const indexToBeRemoved = allNewTasks.findIndex(newTask => {
      return newTask.id === task.id;
    });

    allNewTasks.splice(indexToBeRemoved, 1);

    this.setState({
      allTasks: allNewTasks
    });
  };

  clearAllTasks = () => {
    this.setState({
      allTasks: []
    });
  };

  saveAllTasks = () => {
    const tasksToSave = JSON.stringify(this.state.allTasks);
    window.localStorage.setItem("allTasks", tasksToSave);
  };

  getTodoListElements = () => {
    const todoTaskList = this.state.allTasks.filter(task => {
      return task.isDone === false;
    });

    const todoListElements = todoTaskList.map(task => {
      return (
        <Task
          task={task}
          buttonText={"Completa"}
          onCompleteTask={this.onCompleteTask}
          onUpdateTask={this.onUpdateTask}
          onRemoveTask={this.onRemoveTask}
        />
      );
    });

    return todoListElements;
  }

  getDoneListElements = () => {
    const doneTaskList = this.state.allTasks.filter(task => {
      return task.isDone === true;
    });

    const doneListElements = doneTaskList.map(task => {
      return (
        <Task
          task={task}
          buttonText={"Incompleta"}
          onCompleteTask={this.onInCompleteTask}
          onUpdateTask={this.onUpdateTask}
          onRemoveTask={this.onRemoveTask}
        />
      );
    });

    return doneListElements;
  }

  render() {
    const todoListElements = this.getTodoListElements();
    const doneListElements = this.getDoneListElements();

    return (
      <div>
        <button onClick={this.clearAllTasks}>Limpar Todas as Tasks</button>
        <button onClick={this.saveAllTasks}>Salvar Tasks</button>
        <hr />
        <span>Crie sua nova tarefa: </span>
        <input
          type="text"
          value={this.state.currentTask}
          onChange={this.onChangeCurrentTask}
        />
        <button onClick={this.onClickCreateTask}>Criar Tarefa</button>
        <hr />
        <p>Pendentes:</p>
        <AllTasksWrapper>{todoListElements}</AllTasksWrapper>
        <hr />
        <p>Completas:</p>
        <AllTasksWrapper>{doneListElements}</AllTasksWrapper>
      </div>
    );
  }
}

render(<App />, document.getElementById("root"));