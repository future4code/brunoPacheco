import React from "react";
import styled from "styled-components";

const TaskInput = styled.input`
  margin: 10px 0;
`;

export const Task = props => {
  return (
    <div>
      <button onClick={() => props.onCompleteTask(props.task)}>
        {props.buttonText}
      </button>
      <TaskInput
        type="text"
        value={`${props.task.text}`}
        onChange={event => props.onUpdateTask(event, props.task)}
      />
      <button onClick={() => props.onRemoveTask(props.task)}>
        Remover Task
      </button>
    </div>
  );
};

export default Task;
