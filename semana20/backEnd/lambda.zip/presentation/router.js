"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const createUserUC_1 = require("../business/usecases/createUserUC");
const userDatabase_1 = require("../data/userDatabase");
const bcryptService_1 = require("../services/cryptography/bcryptService");
const authenticationService_1 = require("../services/authentication/authenticationService");
const generateId_1 = require("../services/generateId/generateId");
const loginUserUC_1 = require("../business/usecases/loginUserUC");
const getAllUsersUC_1 = require("../business/usecases/getAllUsersUC");
const changeUsersPassword_1 = require("../business/usecases/changeUsersPassword");
const getTokenFromHeaders = (headers) => {
    return headers["auth"] || "";
};
class ApiRouter {
    static handleRoute(path, event) {
        return __awaiter(this, void 0, void 0, function* () {
            switch (path) {
                case "/signup":
                    try {
                        const user = {
                            name: event.body.name,
                            email: event.body.email,
                            password: event.body.password,
                            birthDate: event.body.birthDate,
                            photo: event.body.photo
                        };
                        const createUserUC = new createUserUC_1.CreateUserUC(new userDatabase_1.UserDatabase(), new generateId_1.GenerateID(), new bcryptService_1.BcryptService(), new authenticationService_1.AuthenticationService());
                        const result = {
                            authentication: yield createUserUC.execute(user)
                        };
                        return {
                            status: 200,
                            result,
                            message: `Usuário ${user.name} criado com sucesso!`
                        };
                    }
                    catch (error) {
                        console.log(error.message);
                    }
                case "getallusers":
                    try {
                        const createUserUC = new getAllUsersUC_1.GetAllUsersUC(new userDatabase_1.UserDatabase());
                        const result = yield createUserUC.execute();
                        return {
                            result
                        };
                    }
                    catch (error) {
                        console.log(error.message);
                    }
                case "login":
                    try {
                        const loginUserUC = new loginUserUC_1.LoginUserUC(new userDatabase_1.UserDatabase(), new bcryptService_1.BcryptService(), new authenticationService_1.AuthenticationService());
                        const result = yield loginUserUC.execute({
                            email: event.body.email,
                            password: event.body.password
                        });
                        return {
                            result
                        };
                    }
                    catch (error) {
                        console.log(error.message);
                    }
                case "changepassword":
                    try {
                        const changePasswordUC = new changeUsersPassword_1.ChangeUsersPasswordUC(new authenticationService_1.AuthenticationService(), new userDatabase_1.UserDatabase(), new bcryptService_1.BcryptService());
                        const result = yield changePasswordUC.execute({
                            token: getTokenFromHeaders(event.headers),
                            oldPassword: event.body.oldPassword,
                            newPassword: event.body.newPassword
                        });
                        return {
                            result
                        };
                    }
                    catch (error) {
                        console.log(error.message);
                    }
                default:
                    throw new Error("Rota não existe");
            }
        });
    }
}
exports.ApiRouter = ApiRouter;
