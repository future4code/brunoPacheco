"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const changeUsersPassword_1 = require("./../business/usecases/changeUsersPassword");
const loginUserUC_1 = require("./../business/usecases/loginUserUC");
const express_1 = __importDefault(require("express"));
const createUserUC_1 = require("../business/usecases/createUserUC");
const userDatabase_1 = require("../data/userDatabase");
const generateId_1 = require("../services/generateId/generateId");
const authenticationService_1 = require("../services/authentication/authenticationService");
const bcryptService_1 = require("../services/cryptography/bcryptService");
const getAllUsersUC_1 = require("../business/usecases/getAllUsersUC");
const app = express_1.default();
app.use(express_1.default.json()); // Linha mágica (middleware)
const getTokenFromHeaders = (headers) => {
    return headers["auth"] || "";
};
app.post("/signup", (request, response) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const user = {
            name: request.body.name,
            email: request.body.email,
            password: request.body.password,
            birthDate: request.body.birthDate,
            photo: request.body.photo
        };
        const createUserUC = new createUserUC_1.CreateUserUC(new userDatabase_1.UserDatabase(), new generateId_1.GenerateID(), new bcryptService_1.BcryptService(), new authenticationService_1.AuthenticationService());
        const result = {
            authentication: yield createUserUC.execute(user)
        };
        return {
            status: 200,
            result,
            message: `Usuário ${user.name} criado com sucesso!`
        };
    }
    catch (error) {
        console.log("primeiro erro: ", error.message);
        response.status(404).send(error.message);
    }
}));
app.get("/getallusers", (request, response) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const createUserUC = new getAllUsersUC_1.GetAllUsersUC(new userDatabase_1.UserDatabase());
        const result = yield createUserUC.execute();
        response.status(200).send(result);
    }
    catch (error) {
        response.status(404).send(error.message);
    }
}));
app.post('/login', (request, response) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const loginUserUC = new loginUserUC_1.LoginUserUC(new userDatabase_1.UserDatabase(), new bcryptService_1.BcryptService(), new authenticationService_1.AuthenticationService());
        const result = yield loginUserUC.execute({
            email: request.body.email,
            password: request.body.password
        });
        response.status(200).send(result);
    }
    catch (error) {
        response.status(404).send(Object.assign(Object.assign({}, error), { message: error.message }));
    }
}));
app.post("/changePassword", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const changePasswordUC = new changeUsersPassword_1.ChangeUsersPasswordUC(new authenticationService_1.AuthenticationService(), new userDatabase_1.UserDatabase(), new bcryptService_1.BcryptService());
        const result = yield changePasswordUC.execute({
            token: getTokenFromHeaders(req.headers),
            oldPassword: req.body.oldPassword,
            newPassword: req.body.newPassword
        });
        res.status(200).send(result);
    }
    catch (err) {
        res.status(400).send({
            errorMessage: err.message
        });
    }
}));
exports.default = app;
