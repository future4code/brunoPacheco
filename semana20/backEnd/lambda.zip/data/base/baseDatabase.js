"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const knex_1 = __importDefault(require("knex"));
class BaseDatabase {
    constructor() {
        this.connection = knex_1.default({
            client: "mysql",
            connection: {
                host: "ec2-3-84-38-207.compute-1.amazonaws.com",
                user: "bruno",
                password: process.env.SENHA_FUTURETUBE,
                database: "dbaBruno"
            }
        });
    }
}
exports.BaseDatabase = BaseDatabase;
