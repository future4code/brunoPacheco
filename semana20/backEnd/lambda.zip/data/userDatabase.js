"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const baseDatabase_1 = require("./base/baseDatabase");
const user_1 = require("../business/entities/user");
class UserDatabase extends baseDatabase_1.BaseDatabase {
    createUser(user) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection.raw(`
            INSERT INTO futureTube_Users (id,name,email,password,birthDate, photo)
            VALUES (
            "${user.getId()}",
            "${user.getName()}",
            "${user.getEmail()}",
            "${user.getPassword()}",
            "${user.getBirthDate()}",
            "${user.getPhoto()}");
        `);
        });
    }
    getAllUsers() {
        return __awaiter(this, void 0, void 0, function* () {
            const allUsers = yield this.connection.raw(`
            SELECT * FROM futureTube_Users ;
        `);
            return allUsers[0].map(this.dbModelToUser);
        });
    }
    dbModelToUser(dbModel) {
        return new user_1.User(dbModel.id, dbModel.name, dbModel.email, dbModel.password, dbModel.birth_date, dbModel.picture);
    }
    verifyUserExists(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = yield this.connection.raw(`
            SELECT * FROM futureTube_Users WHERE id="${id}";
        `);
            return user;
        });
    }
    getUserByEmail(email) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = yield this.connection.raw(`
            SELECT * FROM futureTube_Users WHERE email="${email}";
        `);
            return this.dbModelToUser(user[0][0]);
        });
    }
    updatePassword(id, newPassword) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.connection.raw(`
            UPDATE futureTube_Users SET password="${newPassword}" WHERE id="${id}";
        `);
        });
    }
    getUserById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = yield this.connection.raw(`
            SELECT * from futureTube_users WHERE id="${id}";
        `);
            const returnedUser = this.dbModelToUser(user[0][0]);
            if (!returnedUser) {
                throw new Error("Usuário não encontrado");
            }
            return new user_1.User(returnedUser.getId(), returnedUser.getName(), returnedUser.getEmail(), returnedUser.getPassword(), returnedUser.getBirthDate(), returnedUser.getPhoto());
        });
    }
}
exports.UserDatabase = UserDatabase;
