"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
let path = `../.env`;
dotenv.config(path);
exports.SENHA_FUTURETUBE = process.env.SENHA_FUTURETUBE;
exports.JWT_SECRET = process.env.JWT_SECRET;
